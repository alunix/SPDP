<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="clear: both">
                    <h6 style="float: left; margin:5px;">Analitik permohonan tahun <?php echo e($year_report); ?></h6> 
                </div>

                <h5>Purata masa diperlukan untuk meluluskan satu permohonan = <?php echo e($avg_duration); ?> jam</h5>
                <h5>Jumlah permohonan diluluskan : <?php echo e($lulus->count()); ?></h5>

                <div class="card-body">

                <div class="row">
            
            <div class="col-md-6"> 
            <?php echo $chart->container(); ?>

            <?php echo $chart->script(); ?>

            </div>

            
            
            <div class="col-md-6"> 
               <?php echo $pie_chart->container(); ?>

               <?php echo $pie_chart->script(); ?>

            </div>

            <div class="col-md-6"> 
               <?php echo $line_chart->container(); ?>

               <?php echo $line_chart->script(); ?>

            </div>
                </div>
                <table class="table table-striped">

<thead>
    <tr>
    <th scope="col">No</th>
    <th scope="col">Fakulti</th>
    <th scope="col">Jumlah permohonan</th>
    <th scope="col">Jumlah permohonan diluluskan</th>
    <th scope="col">Jumlah perlu penambahbaikkan</th>
    <th scope="col">Jumlah dokumen permohonan</th>
    </tr>
</thead>
<tbody>
<?php $__currentLoopData = $permohonans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permohonan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th scope="row"><?php echo e($loop->iteration); ?></th>
<td> <?php echo e($permohonan["fakulti_nama"]); ?></td> 
<td> <?php echo e($permohonan["jumlah_permohonan"]); ?></td> 
<td> <?php echo e($permohonan["jumlah_diluluskan"]); ?></td> 
<td> <?php echo e($permohonan["jumlah_penambahbaikkan"]); ?></td> 
<td> <?php echo e($permohonan["jumlah_dokumen_permohonan"]); ?></td> 
<td><a href="<?php echo e(route('analitik.fakulti',$permohonan['fakulti_id'])); ?>" class="btn btn-primary">SELECT</a></td>


</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>










</tbody>
</table>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>