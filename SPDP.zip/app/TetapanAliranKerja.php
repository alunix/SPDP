<?php

namespace SPDP;

use Illuminate\Database\Eloquent\Model;

class TetapanAliranKerja extends Model
{
    protected $table = 'tetapan_aliran_kerjas';
   protected $primaryKey = 'tetapan_id';
}
