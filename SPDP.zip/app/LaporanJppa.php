<?php

namespace SPDP;

use Illuminate\Database\Eloquent\Model;

class LaporanJppa extends Model
{
    protected $primaryKey = 'laporan_jppa_id';
    protected $table = 'laporan_jppas';
}
