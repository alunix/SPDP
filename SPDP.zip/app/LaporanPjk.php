<?php

namespace SPDP;

use Illuminate\Database\Eloquent\Model;

class LaporanPjk extends Model
{
    protected $primaryKey = 'laporan_pjk_id';
    protected $table = 'laporan_pjks';
}
