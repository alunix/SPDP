<?php $__env->startSection('pageTitle', 'Tetapan'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Tetapan profil</div>

            <div class="card-body">
            <form class="form-prevent-double-submits" method="POST" action="<?php echo e(route('settings.submit')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text"  value="<?php echo e(@$user->name); ?>" class="form-control" name="name"  required autofocus readonly>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="text"  value="<?php echo e($user->email); ?>" class="form-control" name="email"  required autofocus >
                            </div>
                        </div>
                        
                        <?php if(Auth::user()->role != "pjk"): ?>
                               
                    

                        <div class="form-group row">
                            <label for="fakulti" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fakulti')); ?></label>

                            <div class="col-md-6">

                            <select class=”form-control” name='fakulti' style="width:330px;" id='fakulti' required>
                                
                                <?php if($fakultis->count()): ?>
                                <?php $__currentLoopData = $fakultis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fakulti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($fakulti->fakulti_id); ?>" <?php echo e($selectedFakulti == $fakulti->fakulti_id ? 'selected="selected"' : ''); ?>><?php echo e($fakulti->f_nama); ?></option>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                            </select>

                            </div>
                        </div>
                        <?php endif; ?>

                        
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary double-submit-prevent">
                                    <?php echo e(__('Kemaskini')); ?>

                                </button>
                            </div>
                        </div>

                         <hr style="border-color:white;">
                        

                       
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>