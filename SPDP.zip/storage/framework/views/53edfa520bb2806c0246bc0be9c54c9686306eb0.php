<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Tetapan aliran kerja</div>

            <div class="card-body">
            <form class="form-prevent-double-submits" method="POST" action="<?php echo e(route('aliranKerja.settings.submit')); ?>">
                        <?php echo csrf_field(); ?>

                    

                        <div class="form-group row">
                            <label for="id_pjk" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Pusat Jaminan Kualiti')); ?></label>

                            <div class="col-md-6">
                            <select class=”form-control” name="id_pjk" style="width:330px;" id='id_pjk' required>
                                
                            <?php if($pjks->count()): ?>
                            <?php $__currentLoopData = $pjks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pjk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($pjk->id); ?>" <?php echo e($selectedPjk == $pjk->id ? 'selected="selected"' : ''); ?>><?php echo e($pjk->name); ?></option>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            
                            </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="id_jppa" class="col-md-4 col-form-label text-md-right"><?php echo e(__('JPPA')); ?></label>

                            <div class="col-md-6">
                            <select class=”form-control” name="id_jppa" style="width:330px;" id="id_jppa" required>
                                
                            <?php if($jppas->count()): ?>
                            <?php $__currentLoopData = $jppas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jppa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jppa->id); ?>" <?php echo e($selectedJppa == $jppa->id ? 'selected="selected"' : ''); ?>><?php echo e($jppa->name); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                            <?php endif; ?>
                            
                            </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="id_senat" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Senat')); ?></label>

                            <div class="col-md-6">
                            
                            <select class=”form-control” name='id_senat' style="width:330px;" id='id_senat' required>
                                
                                <?php if($senats->count()): ?>
                                <?php $__currentLoopData = $senats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $senat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($senat->id); ?>" <?php echo e($selectedSenat == $senat->id ? 'selected="selected"' : ''); ?>><?php echo e($senat->name); ?></option>   
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                                </select>

                            </div>
                        </div>

                        
                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary double-submit-prevent">
                                    <?php echo e(__('Kemaskini')); ?>

                                </button>
                            </div>
                        </div>

                         <hr style="border-color:white;">
                        

                       
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>