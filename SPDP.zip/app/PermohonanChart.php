<?php

namespace SPDP;

use Illuminate\Database\Eloquent\Model;

class PermohonanChart extends Model
{
    //
}
