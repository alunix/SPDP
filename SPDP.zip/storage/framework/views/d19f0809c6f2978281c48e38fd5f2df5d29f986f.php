<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Pelantikan Panel Penilai </div>

            <div class="card-body">
                      
                    
                     <form class="form-prevent-double-submits" method="POST" action="<?php echo e(route('pelantikan_penilai.submit',['permohonan' => $permohonan->permohonan_id])); ?>"  enctype="multipart/form-data" >
                     <?php echo method_field('patch'); ?>                 
                


                        <?php echo csrf_field(); ?>

                            
        
                            <div class="form-group row">
                            <label for="doc_title" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tajuk Program')); ?></label>

                            <div class="col-md-6">
                                
                                <input id="doc_title" type="text" value="<?php echo e(@$permohonan['doc_title']); ?>"  class="form-control" name="doc_title"  required autofocus readonly>
                               
                            </div>
                        </div>
                            

                        <div class="form-group row">
                            <label for="nama_penghantar" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama penghantar')); ?></label>

                            <div class="col-md-6">
                                <input id="nama_penghantar" type="text"  value="<?php echo e($permohonan->user->name); ?>" class="form-control" name="nama_penghantar"  required autofocus readonly>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fakulti" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fakulti')); ?></label>

                            <div class="col-md-6">
                                <input id="fakulti" type="text"  value="<?php echo e($permohonan->user->fakulti->fnama_kod); ?>" class="form-control" name="fakulti"  required autofocus readonly>

                               
                            </div>
                        </div>
                  

                        <div class="form-group row">
                            <label for="created_at" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tarikh dihantar')); ?></label>

                            <div class="col-md-6">
                                <input id="created_at" type="text" value="<?php echo e($permohonan->created_at); ?>" class="form-control" name="created_at"  required autofocus readonly>

                               
                            </div>
                        </div> 

                         <div class="form-group row">
                             <label for="file_link" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Link Kepada File')); ?></label>

                                <div class="col-md-6">
                                <a href ="<?php echo asset("storage/cadangan_permohonan_baharu/$dp->file_link")?>"><?php echo e(basename($dp->file_name)); ?> </a>
                                </div>

                        </div>   

                        <div class="form-group row">
                            <label for="deadline" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tarikh akhir/Deadline')); ?></label>

                            <div class="col-md-6">
                                <input id="deadline" type="datetime-local"   class="form-control" name="deadline"  required>
                            </div>
                        </div>

                        

                        <table class="table table-striped">

<thead>
    <tr>
    <th scope="col">No</th>
    <th scope="col">Nama</th>
    <th scope="col">Email</th>
    <th scope="col">Pelantikan</th>


    
    </tr>
</thead>
<tbody>
<?php if( ! $users->isEmpty() ): ?>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th scope="row"><?php echo e($user->id); ?></th>
<td><?php echo e($user->name); ?></td>               
<td><?php echo e($user->email); ?></td>
<td> <input type="radio" name="checked[]" value="<?php echo e($user->id); ?>"> </td> 
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</tbody>
</table>

<br>


 

<div class="form-group row mb-0">
    <div class="col-md-6 offset-md-5">

        <button type="submit" class="btn btn-success double-submit-prevent"  value="accept-program" name="submitbutton">
        <?php echo e(__('Hantar')); ?>

        </button>
        
       
     

    </div>
</div>







 <hr style="border-color:white;">



</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>