<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Lampiran Perakuan PJK</div>

            <div class="card-body">
                    
                     <form class="form-prevent-double-submits"  method="POST" action="<?php echo e(route('pjk.perakuan.submit',['permohonan'=>$permohonan->permohonan_id])); ?>" enctype="multipart/form-data" >
                     <?php echo method_field('patch'); ?>        
                        <?php echo csrf_field(); ?>
        
                        <div class="form-group row">
                            <label for="doc_title" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tajuk Permohonan')); ?></label>
                            <div class="col-md-6">
                                <input id="doc_title" type="text" value="<?php echo e($permohonan->doc_title); ?>"  class="form-control" name="doc_title"  required autofocus readonly>
                            </div>
                        </div>
                            

                        <div class="form-group row">
                            <label for="nama_penghantar" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama Penghantar')); ?></label>
                            <div class="col-md-6">
                                <input id="nama_penghantar" type="text"  value="<?php echo e($permohonan->user->name); ?>" class="form-control" name="nama_penghantar"  required autofocus readonly>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="fakulti" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fakulti')); ?></label>
                            <div class="col-md-6">
                                <input id="fakulti" type="text"  value="<?php echo e($permohonan->user->fakulti->f_nama); ?>" class="form-control" name="fakulti"  required autofocus readonly>
                            </div>
                        </div>
                  

                        <div class="form-group row">
                            <label for="created_at" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tarikh dihantar')); ?></label>
                            <div class="col-md-6">
                                <input id="created_at" type="text" value="<?php echo e($permohonan->created_at); ?>" class="form-control" name="created_at"  required autofocus readonly>
                            </div>
                        </div> 
                              

                        <div class="form-group row">
                             <label for="file_link" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Lampiran permohonan')); ?></label>
                                <div class="col-md-6">
                                <a href ="<?php echo asset("storage/cadangan_permohonan_baharu/{$permohonan->dokumen_permohonan()->file_link}")?>"><?php echo e(basename($permohonan->dokumen_permohonan()->file_name)); ?> </a> 
                                </div>
                        </div>

                       
                         <div class="form-group row">
                            <label for="perakuan_pjk" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Lampiran perakuan PJK')); ?></label>
                            <div class="col-md-6">
                                <input id="perakuan_pjk" type="file" class="form-control<?php echo e($errors->has('perakuan_pjk') ? ' is-invalid' : ''); ?>" name="perakuan_pjk" value="<?php echo e(old('perakuan_pjk')); ?>" required autofocus>

                                <?php if($errors->has('perakuan_pjk')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('perakuan_pjk')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> 

                        <div class="form-group row mb-0">
    <div class="col-md-6 offset-md-5">

        <button type="submit" class="btn btn-success double-submit-prevent" value="accept-permohonan" name="submitbutton">
        <?php echo e(__('Hantar')); ?>

        </button>

        <a href="<?php echo e(route('laporan.permohonanTidakDilulus',$permohonan->permohonan_id)); ?>">
                                    <input type="button" class="btn btn-danger" value="Penambahbaikan" />
                                    
                            </a>

        <br><br>
        
       
     

    </div>
</div>

    


<table class="table table-striped">

<thead>
    <tr>
    <th scope="col">No</th>
    <th scope="col">Laporan</th>
    <th scope="col">Dihantar</th>
    <th scope="col">Pihak</th>
    <th scope="col">Komen</th>
    <th scope="col">Versi</th>
    <th scope="col">Tarikh/Masa Laporan</th> 
    
    </tr>
</thead>
<tbody>
<?php if( ! $laporans->isEmpty() ): ?>
<?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th scope="row"><?php echo e($loop->iteration); ?></th>
<td><a href ="<?php echo asset("storage/laporan/$laporan->tajuk_fail_link")?>"><?php echo e(basename($laporan->tajuk_fail_link)); ?></td> </a>
<td> <?php echo e($laporan->id_penghantar_nama->name); ?></td>
<td> <?php echo e($laporan->id_penghantar_nama->role); ?></td>
<td> <?php echo e($laporan->komen); ?></td>
<td> <?php echo e($laporan->versi_laporan); ?></td>
<td> <?php echo e($laporan->created_at); ?></td>


</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</tbody>
</table>



<?php else: ?>

<p> Tiada laporan telah dikeluarkan</p>

<?php endif; ?>
                        

                        




 








 <hr style="border-color:white;">



</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>