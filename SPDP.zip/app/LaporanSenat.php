<?php

namespace SPDP;

use Illuminate\Database\Eloquent\Model;

class LaporanSenat extends Model
{
    protected $primaryKey = 'laporan_senat_id';
    protected $table = 'laporan_senats';
}
