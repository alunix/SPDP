<?php $__env->startSection('pageTitle', 'Senarai dokumen'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="width:65rem;">
                <div class="card-header" >Sejarah versi dokumen</div>

                <div class="card-body">
               
    <div class="container">
  

<h5>Dokumen yang telah dihantar</h5>

<table class="table table-striped">

<thead>
    <tr>
    <th scope="col">No</th>
    <th scope="col">Dokumen</th>
    <th scope="col">Saiz</th>
    <th scope="col">Komen</th>
    <th scope="col">Versi</th>
    <th scope ="col">Jumlah laporan</th>
    <th scope="col">Tarikh/Masa Penghantaran</th>
 
    
    
    </tr>
</thead>
<tbody>
<?php if( ! $dokumen_permohonans->isEmpty() ): ?>
<?php $__currentLoopData = $dokumen_permohonans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>

<th scope="row"><?php echo e($dk->versi); ?></th>

<td><a href ="<?php echo asset("storage/cadangan_permohonan_baharu/$dk->file_link")?>"><?php echo e(basename($dk->file_name)); ?></td> </a>
<td> <?php echo e($dk->file_size); ?> KB</td>
<td> <?php echo e($dk->komen); ?></td> 
<td> <?php echo e($dk->versi); ?></td>     
<td> <?php echo e($dk->laporans->count()); ?></td>
<td> <?php echo e($dk->created_at->format('d/m/Y h:i a')); ?></td>




<td><a href="<?php echo e(route('senaraiLaporan.show',$dk->dokumen_permohonan_id)); ?>" class="btn btn-primary">Senarai laporan</a></td>


</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<?php else: ?>

<p> Tiada dokumen permohonan telah dihantar</p>

<?php endif; ?>

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>