<?php $__env->startSection('pageTitle', 'Kemajuan permohonan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="width:65rem;">
                <div class="card-header" >Kemajuan Permohonan</div>

                <div class="card-body">
               
    <div class="container">
 
   <h5>Permohonan ID :<?php echo e($permohonan->id); ?></h5>

   <?php if(($permohonan->status_permohonan_id == 8 or $permohonan->status_permohonan_id == 9 or $permohonan->status_permohonan_id == 10 or $permohonan->status_permohonan_id == 11  ) and (Auth::user()->role == "fakulti")): ?>
   <a class="btn icon-btn btn-info" href="<?php echo e(route('dokumenPermohonan.penambahbaikkan.show',$permohonan->permohonan_id)); ?>">
Muat naik penambahbaikkan
</a>
<br><br>
    <?php else: ?>
    <?php endif; ?>


<h5>Kemajuan permohonan</h5>

         <table class="table table-striped">

<thead>
    <tr>
    <th scope="col">No</th>
    <th scope="col">Status Permohonan</th>
    <th scope="col">Tarikh/Masa Status</th> 
    
    </tr>
</thead>
<tbody>
<?php if( ! $kjs->isEmpty() ): ?>
<?php $__currentLoopData = $kjs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th scope="row"><?php echo e($loop->iteration); ?></th>
<td> <?php echo e($kj->statusPermohonan->status_permohonan_huraian); ?></td>   
<td> <?php echo e($kj->created_at->format('h:i a d/m/Y')); ?></td>               


</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</tbody>
</table>



<?php else: ?>

<p> Tiada kemajuan permohonan </p>

<?php endif; ?>



<h5> Semua laporan yang telah dikeluarkan</h5>

<table class="table table-striped">

<thead>
    <tr>
    <th scope="col">No</th>
    <th scope="col">Laporan</th>
    <th scope="col">Dihantar</th>
    <th scope="col">Pihak</th>
    <th scope="col">Komen</th>
    <th scope="col">Versi</th>
    <th scope="col">Tarikh/Masa Laporan</th> 
    
    </tr>
</thead>
<tbody>
<?php if( ! $laporans->isEmpty() ): ?>
<?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th scope="row"><?php echo e($loop->iteration); ?></th>
<td><a href ="<?php echo asset("storage/cadangan_permohonan_baharu/$laporan->tajuk_fail_link")?>"><?php echo e(basename($laporan->tajuk_fail_link)); ?></td> </a>
<td> <?php echo e($laporan->id_penghantar_nama->name); ?></td>
<td> <?php echo e($laporan->id_penghantar_nama->role); ?></td>
<td> <?php echo e($laporan->komen); ?></td>
<td> <?php echo e($laporan->versi_laporan); ?></td>
<td> <?php echo e($laporan->created_at->format('h:i a d/m/Y')); ?></td>


</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</tbody>
</table>



<?php else: ?>

<p> Tiada laporan telah dikeluarkan</p>

<?php endif; ?>



                
                    
    
                            
                           

                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>