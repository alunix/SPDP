<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Halaman Pusat Jaminan Kualiti</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                       <form action="<?php echo e(route('senaraiPermohonanBaharu')); ?>">
    <input type="submit" value="Lihat Semua Permohonan Yang Diterima" />
</form>


                    

 <form action="<?php echo e(route('pjk.senarai_perakuan.show')); ?>">
    <input type="submit" value="Perakuan laporan penilaian" />
</form>



<form action="<?php echo e(route('register.panel_penilai.show')); ?>">
    <input type="submit" value="Daftar Panel Penilai" />
</form>

<form action="<?php echo e(route('penilaian.show')); ?>">
    <input type="submit" value="Senarai penilaian" />
</form>

<form action="<?php echo e(route('analitik.permohonan.dashboard')); ?>">
    <input type="submit" value="Analitik permohonan" />
</form>






                
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>