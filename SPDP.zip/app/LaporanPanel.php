<?php

namespace SPDP;

use Illuminate\Database\Eloquent\Model;

class LaporanPanel extends Model
{
    protected $primaryKey = 'laporan_panel_id';
    protected $table = 'laporan_panels';
}
