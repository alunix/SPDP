<?php

namespace SPDP\Charts;

use ConsoleTVs\Charts\Classes\Highcharts\Chart;

class JenisPermohonanChart extends Chart
{
    /**
     * Initializes the chart.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }
}
