<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h4>Senarai permohonan untuk diperakukan</h4></div>

            <div class="card-body">
           

                     

                                             

      <a href="<?php echo e(url()->previous()); ?>" class="btn btn-default">Back</a>
                      



<table class="table table-striped">

<thead>
    <tr>
    <th scope="col">Permohonan ID</th>
    <th scope="col">Jenis permohonan</th>
    <th scope="col">Nama program/kursus</th>
    <th scope="col">Nama penghantar</th>
    <th scope="col">Fakulti</th>
    <th scope="col">Tarikh dihantar</th>


    
    </tr>
</thead>
<tbody>

 <!-- <table class="table  table-striped"> -->

<?php if( ! $permohonans->isEmpty() ): ?>
<?php $__currentLoopData = $permohonans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permohonan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th scope="row"><?php echo e($permohonan->permohonan_id); ?></th>
<td><?php echo e($permohonan->jenis_permohonan->jenis_permohonan_huraian); ?> </td>
<td><?php echo e($permohonan->doc_title); ?></td>   
<td><?php echo e($permohonan->user->name); ?> </td>
<td><?php echo e($permohonan->user->fakulti); ?> </td> 
<td><?php echo e($permohonan->created_at->format('h:i a d/m/Y')); ?>  </td> 

<td><a href="<?php echo e(route('pjk.perakuan.show',$permohonan->permohonan_id)); ?>" class="btn btn-primary">SELECT</a></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</tbody>
</table>


                        

                         

                        

                       
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>