<?php $__env->startSection('content'); ?>

<div class="container">
<h3 class="title-5 m-b-35">Senarai permohonan perakuan</h3>
                                <div class="table-data__tool">
                                    <div class="table-data__tool-left">
                                       
                                    </div>
                              
                                </div>
                                <h4>Jumlah permohonan perakuan : <?php echo e($permohonans->count()); ?></h4>
                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr>
                                                
                                                <th>no</th>
                                                <th>id</th>
                                                <th>jenis</th>
                                                <th>bil penghantaran</th>
                                                <th>nama program/kursus</th>
                                                <th>penghantar</th>
                                                <th>fakulti</th>
                                                <th>tarikh</th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        <?php if( ! $permohonans->isEmpty() ): ?>
                                        <?php $__currentLoopData = $permohonans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permohonan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="tr-shadow">
                                           
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td><?php echo e($permohonan->permohonan_id); ?></td>
                                                <td><?php echo e($permohonan->jenis_permohonan->jenis_permohonan_huraian); ?></td>
                                                <td><?php echo e($permohonan->version_counts()); ?></td>
                                                <td><?php echo e($permohonan->doc_title); ?></td>   
                                                <td><?php echo e($permohonan->user->name); ?> </td>
                                                <td><?php echo e($permohonan->user->fakulti->fnama_kod); ?> </td> 
                                                <td><?php echo e($permohonan->created_at->format('h:i a d/m/Y')); ?>  </td> 
                                                <td>
                                                    <div class="table-data-feature">
                                                        <button onclick="location.href='<?php echo e(route('pjk.perakuan.show',$permohonan->permohonan_id)); ?>'" class="item" data-toggle="tooltip" data-placement="top" title="Lihat permohonan">
                                                            <i  class="zmdi zmdi-zoom-in"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           
                                            <tr class="spacer"></tr>
                                        </tbody>
                                    </table>

                                    <?php else: ?>
                                    <p> Tiada permohonan telah dijumpai </p>
                                    <?php endif; ?>
                                </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>