<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Memuat naik penambahbaikkan</div>

            <div class="card-body">
                 
                    
                     <form class="form-prevent-double-submits" method="POST" action="<?php echo e(route('dokumenPermohonan.penambahbaikkan.submit',['permohonan'=>$permohonan->permohonan_id])); ?>" enctype="multipart/form-data" >
                     
                        <?php echo csrf_field(); ?>
                            <div class="form-group row">
                            <label for="doc_title" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tajuk Permohonan')); ?></label>

                            <div class="col-md-6">
                               
                                <input id="doc_title" type="text" value="<?php echo e($permohonan->doc_title); ?>"  class="form-control" name="doc_title"  required autofocus readonly>
                               
                            </div>
                        </div>
                            

                        <div class="form-group row">
                            <label for="nama_penghantar" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nama Penghantar')); ?></label>

                            <div class="col-md-6">
                                <input id="nama_penghantar" type="text"  value="<?php echo e($permohonan->user->name); ?>" class="form-control" name="nama_penghantar"  required autofocus readonly>

                               
                            </div>
                        </div>
                     
                  

                        <div class="form-group row">
                            <label for="created_at" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Tarikh dihantar')); ?></label>

                            <div class="col-md-6">
                                <input id="created_at" type="text" value="<?php echo e($permohonan->created_at); ?>" class="form-control" name="created_at"  required autofocus readonly>

                               
                            </div>
                        </div> 
                        
                        
                         <div class="form-group row">
                            <label for="dokumen" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Fail penambahbaikkan')); ?></label>

                            <div class="col-md-6">
                                <input id="dokumen" type="file" class="form-control<?php echo e($errors->has('dokumen') ? ' is-invalid' : ''); ?>" name="dokumen" value="<?php echo e(old('dokumen')); ?>" required autofocus>

                                <?php if($errors->has('dokumen')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('dokumen')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div> 

                        <div class="form-group row">
                        <label for="summary-ckeditor" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Komen(Tidak diwajibkan)')); ?></label>

                        <div class="col-md-6">
                        <textarea class="form-control" id="summary-ckeditor" name="summary-ckeditor"></textarea>
                        </div>
                        </div>

                        <div class="form-group row mb-0">
    <div class="col-md-6 offset-md-5">

        <button type="submit" class="btn btn-success double-submit-prevent" value="accept-program" name="submitbutton">
        <?php echo e(__('Hantar')); ?>

        </button>

    </div>
</div>
<br>

                        

                        
         <table class="table table-striped">

<thead>
    <tr>
    <th scope="col">No/Versi</th>
    <th scope="col">Fail </th>
    <th scope="col">Saiz</th>
    <th scope="col">Komen</th>
    
    <th scope="col">Tarikh/Masa </th> 
    
    </tr>
</thead>
<tbody>
<?php if( ! $dps->isEmpty() ): ?>
<?php $__currentLoopData = $dps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th scope="row"><?php echo e($dp->versi); ?></th>
<td><a href ="<?php echo asset("storage/cadangan_permohonan_baharu/{$dp->file_link}")?>"><?php echo e(basename($dp->file_name)); ?> </a></td>  
<td> <?php echo e($dp->file_size); ?> KB</td> 
<td> <?php echo e($dp->komen); ?></td> 
<td> <?php echo e($dp->created_at->format('h:i a d/m/Y')); ?> </td> 
  

              



</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>
</table>

<?php else: ?>

<p> Tiada dokumen permohonan telah dijumpai</p>

<?php endif; ?>



    

                        

                        




 








 <hr style="border-color:white;">



</div>
</div>
</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>