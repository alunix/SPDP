<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="clear: both">
                    <h6 style="float: left; margin:5px;"><?php echo e($fakulti->f_nama); ?></h6> 
                </div>
                <h5>Dokumen permohonan dihantar : <?php echo e($dokumen_permohonans->count()); ?></h5>
                <h5>Permohonan dihantar : <?php echo e($permohonans->count()); ?></h5>
               <h5>Jumlah penambahbaikkan : <?php echo e($jumlah_penambahbaikkan); ?></h5>
                <div class="card-body">
                <div class="row">
            
            <div class="col-md-6"> 
               <?php echo $pie_chart->container(); ?>

               <?php echo $pie_chart->script(); ?>

            </div>
                </div>
               <h5>Permohonan perlu penambahbaikkan</h5>
               <table class="table table-striped">

<thead>
    <tr>
    <th scope="col">No</th>
    <th scope="col">ID</th>
    <th scope="col">Jenis</th>
    <th scope="col">Bilangan penghantaran</th>
    <th scope="col">Nama program/semakan</th>
    <th scope="col">Penghantar</th>
    <th scope="col">Tarikh/Masa Penghantaran</th>    
    <th scope="col">Status</th>
    <th scope="col">Tarikh/Masa Status</th>    
    
    </tr>
</thead>
<tbody>
<?php if( ! $permohonans_8->isEmpty() ): ?>
<?php $__currentLoopData = $permohonans_8; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permohonan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th scope="row"><?php echo e($loop->iteration); ?></th>
<td> <?php echo e($permohonan->permohonan_id); ?></td>  
<td> <?php echo e($permohonan->jenis_permohonan->jenis_permohonan_huraian); ?></td>   
<td> <?php echo e($permohonan->version_counts()); ?></td>
<td> <?php echo e($permohonan->doc_title); ?></td>                 
<td><?php echo e($permohonan->user->name); ?></td>
<td> <?php echo e($permohonan->created_at->format('h:i a d/m/Y')); ?></td>
<td><?php echo e($permohonan->status_permohonan->status_permohonan_huraian); ?> </td>
<td> <?php echo e($permohonan->updated_at->format('h:i a d/m/Y')); ?></td>
<td><a href="<?php echo e(route('fakulti.kemajuanPermohonan',$permohonan->permohonan_id)); ?>" class="btn btn-primary">Kemajuan</a></td>
<td><a href="<?php echo e(route('dokumenPermohonan.dihantar',$permohonan->permohonan_id)); ?>" class="btn btn-primary">Dokumen</a></td>



</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>
</table>



<?php else: ?>

<p> Tiada permohonan telah dijumpai </p>

<?php endif; ?>


            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>