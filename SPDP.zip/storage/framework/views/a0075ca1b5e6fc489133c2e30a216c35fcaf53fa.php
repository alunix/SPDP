<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Senarai Penilaian Panel Penilai</div>

            <div class="card-body" style="width:700px;">
    
                  
            
                        <table class="table table-striped">                  
                        

                        <thead>
                            <tr>
                            <th scope="col">Penilaain ID</th>
                            <th scope="col">Permohonan ID</th>
                            <th scope="col">Pelantik(PJK)</th>
                            <th scope="col">Penilai</th>
                            <th scope="col">Tarikh penilaian bermula</th>
                            <th scope="col">Tarikh Akhir/Deadline</th>                          
                            <th scope="col">Tempoh(Hari)</th>
                            <th scope="col"></th>

                            </tr>
                        </thead>
                        <tbody>
                       
                        <?php if( ! $penilaians->isEmpty() ): ?>

                       
        <?php $__currentLoopData = $penilaians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penilaian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row>"><?php echo e($penilaian->penilaian_id); ?></th>
                <th scope="row>"><?php echo e($penilaian->permohonanID); ?></th>
                <th scope="row"><?php echo e($penilaian->id_pelantik); ?></th>
               <th scope="row"><?php echo e($penilaian->id_penilai); ?></th>   
               <th scope="row"><?php echo e($penilaian->created_at); ?></th>                
                <th scope="row"><?php echo e($penilaian->tarikhAkhir); ?></th>
                <th scope="row"><?php echo e($penilaian->tempoh); ?></th>
                <td><a href="<?php echo e(route('view-permohonan-baharu',$penilaian->permohonanID)); ?>" class="btn btn-primary">SELECT</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            No penilaian are found

    <?php endif; ?>
    </tbody>
                        </table>

                         <hr style="border-color:white;">
                        
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>