<?php

namespace SPDP\Http\Controllers;

use SPDP\JenisPermohonan;
use Illuminate\Http\Request;

class JenisPermohonanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \SPDP\JenisPermohonan  $jenisPermohonan
     * @return \Illuminate\Http\Response
     */
    public function show(JenisPermohonan $jenisPermohonan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \SPDP\JenisPermohonan  $jenisPermohonan
     * @return \Illuminate\Http\Response
     */
    public function edit(JenisPermohonan $jenisPermohonan)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \SPDP\JenisPermohonan  $jenisPermohonan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, JenisPermohonan $jenisPermohonan)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \SPDP\JenisPermohonan  $jenisPermohonan
     * @return \Illuminate\Http\Response
     */
    public function destroy(JenisPermohonan $jenisPermohonan)
    {
        //
    }
}
