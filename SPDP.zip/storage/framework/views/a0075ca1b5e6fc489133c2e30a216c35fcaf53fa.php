<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Senarai penilaian permohonan</div>

            <div class="card-body" style="width:500px;">
    
                  
            
                        <table class="table table-striped">                  
                        

                        <thead>
                            <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Jenis permohonan</th>
                            <th scope="col">Tajuk Dokumen</th>
                            <th scope="col">PJK</th>
                            <th scope="col">Panel Penilai</th>                          
                            <th scope="col">JPPA</th>
                            <th scope="col">Senat</th>


                            
                            </tr>
                        </thead>
                        <tbody>
                       
                        <?php if( ! $penilaians->isEmpty() ): ?>

                       
        <?php $__currentLoopData = $penilaians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penilaian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                 
                 
                 <?php if(Auth::user()->role == "pjk"): ?>
                <th scope="row"><a href="/penilaian/<?php echo e($penilaian->id); ?>"><?php echo e($penilaian->id); ?></th>
                
                <?php elseif(Auth::user()->role=="jppa"): ?>
                <th scope="row"><a href="/jppa/penilaian/<?php echo e($penilaian->id); ?>"><?php echo e($penilaian->id); ?></th>
                <?php endif; ?>
                
                <th scope="row>"><?php echo e($penilaian->permohonan->jenis_permohonan->jenis_permohonan_huraian); ?></th>
                <th scope="row>"><?php echo e($penilaian->permohonan->doc_title); ?></th>
                <th scope="row"><?php echo e($penilaian->pjk->name); ?></th>
               <th scope="row"><?php echo e($penilaian->panel_penilai->name); ?></th>           
                <th scope="row"><?php echo e($penilaian->jppa); ?></th>
                <th scope="row"><?php echo e($penilaian->senat); ?></th>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            No penilaian are found

    <?php endif; ?>
    </tbody>
                        </table>

                         <hr style="border-color:white;">
                        
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>