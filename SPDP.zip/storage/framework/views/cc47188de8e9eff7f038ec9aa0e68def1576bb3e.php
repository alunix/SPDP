<?php $__env->startSection('pageTitle', 'Carian'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    
<p> Jumlah carian : <?php echo e($total_count); ?></p>
    <p> Carian <b> <?php echo e($query); ?> </b> adalah :</p>

    <div class="row">
    <div class="col-md-12">
    <form class="au-form-icon--sm" action="/search" method="post">
                                <?php echo csrf_field(); ?>    
                                <input class="au-input--w300 au-input--style2" type="text" name="input-search" placeholder="Cari permohonan & laporan">
                                    <button class="au-btn--submit2" type="submit">
                                        <i class="zmdi zmdi-search"></i>
                                    </button>
    </form>
    </div>
    </div>

    <?php if(Auth::user()->role!="fakulti"): ?>
    <?php if(! $users->isEmpty()): ?>
      
    <h2>Maklumat pengguna</h2>
    <table class="table table-striped">
        <thead>
            <tr>   
                <th>No</th>
                <th>Nama</th>
                <th>E-mel</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr> 
            <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->email); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>
    <?php endif; ?>

    <?php if(! $permohonans->isEmpty()): ?>
     
    <h2>Maklumat permohonan</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Permohonan ID</th>
                <th>Nama program/kursus</th>
                <th>Permohonan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $permohonans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permohonan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($permohonan->permohonan_id); ?></td>
                <td><?php echo e($permohonan->doc_title); ?></td>
                <td><a href="<?php echo e(route('view-permohonan-baharu',$permohonan->permohonan_id)); ?>" class="btn btn-primary">SELECT</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>

    <br>

    <?php if(! $dokumens->isEmpty()): ?>
       
    <h2>Dokumen permohonan</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Dokumen permohonan</th>
                <th>Tajuk dokumen</th>
                <th>Dokumen</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dokumens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokumen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($dokumen->permohonan_id); ?></td>
            <td><?php echo e($dokumen->file_name); ?></td>
            <td><a href ="<?php echo asset("storage/cadangan_permohonan_baharu/$dokumen->file_link")?>"><?php echo e(basename($dokumen->file_name)); ?></td></a>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>
    <br>
    <?php if(! $laporans->isEmpty()): ?>
    <h2>Maklumat laporan</h2>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>Laporan ID</th>
                <th>Nama fail</th>
                <th>Fail</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><?php echo e($laporan->laporan_id); ?></td>
            <td><?php echo e($laporan->tajuk_fail); ?></td>
            <td><a href ="<?php echo asset("storage/laporan/$laporan->tajuk_fail_link")?>"><?php echo e(basename($laporan->tajuk_fail_link)); ?></a></td>

              
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>





</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>