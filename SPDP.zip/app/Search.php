<?php

namespace SPDP;

use Illuminate\Database\Eloquent\Model;

class Search extends Model
{
    //
}
