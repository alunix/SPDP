<?php $__env->startSection('pageTitle', 'Daftar Pengguna'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Daftar pengguna')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register.panel_penilai.submit')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="nama" class="col-md-3"><?php echo e(__('Nama')); ?></label>

                            <div class="col-md-6">
                                <input id="nama" type="text" class="form-control<?php echo e($errors->has('nama') ? ' is-invalid' : ''); ?>" name="nama" value="<?php echo e(old('nama')); ?>" required autofocus>

                                <?php if($errors->has('nama')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('nama')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-3"><?php echo e(__('Alamat e-mel')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" placeholder="name@ukm.edu.my" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                                                <div class="col col-md-3">
                                                    <label class=" form-control-label">Peranan pengguna</label>
                                                </div>
                                                <div class="col col-md-9">
                                                    <div class="form-check">
                                                        <div class="radio">
                                                            <label for="radio1" class="form-check-label ">
                                                                <input type="radio"  id="radio1" name="peranan" value="penilai" class="form-check-input">Panel Penilai
                                                            </label>
                                                        </div>
                                                        <div class="radio">
                                                            <label for="radio2" class="form-check-label ">
                                                                <input type="radio"  id="radio2" name="peranan"value="pjk" class="form-check-input">PJK
                                                            </label>
                                                        </div>
                                                        <div class="radio">
                                                            <label for="radio3" class="form-check-label ">
                                                                <input type="radio"  id="radio3" name="peranan" value="jppa" class="form-check-input">JPPA
                                                            </label>
                                                        </div>
                                                        <div class="radio">
                                                            <label for="radio4" class="form-check-label ">
                                                                <input type="radio"  id="radio4" name="peranan" value="senat" class="form-check-input">Senat
                                                            </label>
                                                        </div>
                                                      
                                                    </div>
                                                </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-3"><?php echo e(__('Kata laluan')); ?></label>

                            <div class="col col-md-9">
                                                    <div class="form-check">
                                                        <div class="radio">
                                                            <label for="autoGenerate" class="form-check-label ">
                                                                <input type="radio"  onclick="myFunction()" id="autoGenerate" name="radios" value="autoGenerate"  class="form-check-input">Auto jana kata laluan
                                                            </label>
                                                        </div>
                                                        <div class="radio">
                                                            <label for="manualGenerate" class="form-check-label ">
                                                                <input type="radio" onclick="myFunction()" id="manualGenerate" name="radios" value="manualGenerate" class="form-check-input">Biar saya tetapkan kata laluan
                                                                
                                                            </label>
                                                        </div>  
                                                        
                            <div id ='showPassword' style='display:none' class="form-group row" >

                            <br>
                            <label for="password" style="font-size:12px" ><?php echo e(__('Kata laluan(6 karakter minimum)')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" onkeyup='check();'  name="password" value="<?php echo e(old('password')); ?>" required >
                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>

                            <label for="password-confirm" style="font-size:12px"  ><?php echo e(__('Taip semula kata laluan')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control<?php echo e($errors->has('password-confirm') ? ' is-invalid' : ''); ?>" onkeyup='check();' name="password-confirm" value="<?php echo e(old('password-confirm')); ?>" required >
                                <?php if($errors->has('password-confirm')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password-confirm')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            </div>                                                      
                                                    </div>
                            </div>


                            
                        </div>

                                            <div class="form-group row mb-0">
                                                <div class="col-md-6 offset-md-4">
                                                    <button type="submit" class="btn btn-primary double-submit-prevent">
                                                        <?php echo e(__('Daftar pengguna')); ?>

                                                    </button>
                                                </div>
                                            </div>
                                            <br>

                        <input  class="au-input--w300 au-input--style2 col-md-6 offset-md-4" type="text" id="myInput" onkeyup="searchFunction()" placeholder="Search for names..">

                        <br>

                        <table class="table table-striped" id="myTable">

<thead>
    <tr>
    <th scope="col">No</th>
    <th scope="col">ID</th>
    <th scope="col">Nama</th>
    <th scope="col">Peranan</th>
    <th scope="col">Email</th>
    <th scope="col">Tarikh pendaftaran</th>

    

    
    </tr>
</thead>
<tbody>
<?php if( ! $users->isEmpty() ): ?>
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<th scope="row"><?php echo e($loop->iteration); ?></th>
<td><?php echo e($user->id); ?></td>  
<td><?php echo e($user->name); ?></td>    
<td><?php echo e($user->role); ?></td>                  
<td><?php echo e($user->email); ?></td>
<td><?php echo e($user->created_at->format('h:i a d/m/Y')); ?></td>

</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</tbody>
</table>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php if($errors->any()): ?>
        <div class="row collapse">
            <ul class="alert-box warning radius">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li> <?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

<script >
function myFunction() {
   var auto = document.getElementById("autoGenerate");
   var manual = document.getElementById("manualGenerate");
   var showPassword = document.getElementById('showPassword');
   var password = document.getElementById("password");
   var confirmed = document.getElementById("password-confirm");
   
  
  if (auto.checked == true){
    showPassword.style.display = "none";
    password.removeAttribute('required');
    confirmed.removeAttribute('required');
    
  } else if (manual.checked == true){
    showPassword.style.display = "block";
        
  }
  else{

  }
}


function searchFunction() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}


var check = function() {
  if (document.getElementById('password').value ==
    document.getElementById('password-confirm').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'Padan';
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'Tidak padan';
  }
}
</script>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>